<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

$config = require __DIR__ . '/config.php';

// Cargar PHPMailer manualmente
require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$subject = trim($_POST['subject'] ?? 'Conversación con el chatbot');

if (!$email) {
    echo json_encode([
        'success' => false,
        'message' => 'Introduce un email válido.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$history = $_SESSION['chat_history'] ?? [];

if (empty($history)) {
    echo json_encode([
        'success' => false,
        'message' => 'No hay conversación para enviar.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$body = $config['site_name'] . "\n\n";
$body .= "Conversación exportada:\n\n";

foreach ($history as $item) {
    $role = $item['role'] === 'assistant' ? 'Asistente' : 'Usuario';
    $body .= $role . ': ' . $item['content'] . "\n\n";
}

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = $config['smtp_host'];
    $mail->SMTPAuth   = true;
    $mail->Username   = $config['smtp_username'];
    $mail->Password   = $config['smtp_password'];
    $mail->Port       = (int)$config['smtp_port'];

    if (($config['smtp_secure'] ?? '') === 'ssl') {
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    } else {
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    }

    $mail->CharSet = 'UTF-8';
    $mail->setFrom($config['from_email'], $config['from_name']);
    $mail->addAddress($email);
    $mail->Subject = $subject;
    $mail->Body    = $body;
    $mail->isHTML(false);

    $mail->send();

    echo json_encode([
        'success' => true,
        'message' => 'Conversación enviada correctamente por SMTP.'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'No se pudo enviar el email.',
        'error'   => $mail->ErrorInfo
    ], JSON_UNESCAPED_UNICODE);
}
