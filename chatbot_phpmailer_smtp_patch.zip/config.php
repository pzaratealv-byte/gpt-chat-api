<?php
return [
    'openai_api_key' => 'PON_AQUI_TU_API_KEY_NUEVA',
    'model'          => 'gpt-4o-mini',
    'from_email'     => 'info@noeliamedrano.es',
    'from_name'      => 'Chatbot Marketing',
    'site_name'      => 'Chatbot de Marketing Digital',

    // CONFIGURACIÓN SMTP
    'smtp_host'      => 'mail.noeliamedrano.es',
    'smtp_port'      => 587,
    'smtp_secure'    => 'tls', // tls o ssl
    'smtp_username'  => 'info@noeliamedrano.es',
    'smtp_password'  => 'PON_AQUI_LA_PASSWORD_DEL_CORREO'
];
