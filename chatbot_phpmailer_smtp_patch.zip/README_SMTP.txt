PARCHE SMTP CON PHPMailer

1. Sustituye tu archivo send_email.php por el incluido aquí.
2. Sustituye tu config.php por el incluido aquí o copia solo los campos SMTP.
3. Descarga PHPMailer desde GitHub.
4. Sube la carpeta PHPMailer dentro de la raíz de tu proyecto, con esta estructura:

/tu-proyecto
    /PHPMailer
        /src
            Exception.php
            PHPMailer.php
            SMTP.php
    config.php
    send_email.php
    chat.php
    index.php

5. Rellena en config.php:
   - smtp_host
   - smtp_port
   - smtp_secure
   - smtp_username
   - smtp_password

Ejemplo típico en Plesk:
- smtp_host: mail.tudominio.com
- smtp_port: 587
- smtp_secure: tls
- smtp_username: tu-correo@tudominio.com
- smtp_password: contraseña real de ese buzón

SI FALLA:
- Revisa que el buzón exista de verdad en Plesk
- Revisa usuario y contraseña
- Prueba puerto 587 (TLS) o 465 (SSL)
- Asegúrate de que el dominio tiene correo activo
