#!/usr/bin/env python3
"""
Ejemplo de uso de GPT Chat API con Python
"""

import requests
import json

# Configuración
API_URL = "https://tudominio.com/api"  # Cambia esto
PASSWORD = "tu-contraseña"  # Cambia esto
SESSION_ID = f"session_python_{__import__('time').time()}"


def login():
    """Iniciar sesión"""
    response = requests.post(
        f"{API_URL}/auth.php?action=login",
        json={"password": PASSWORD}
    )
    return response.json()


def send_message(message):
    """Enviar mensaje al chatbot"""
    response = requests.post(
        f"{API_URL}/chat.php",
        json={
            "message": message,
            "sessionId": SESSION_ID
        }
    )
    return response.json()


def generate_image(prompt, size="1024x1024"):
    """Generar imagen con DALL-E"""
    response = requests.post(
        f"{API_URL}/generate-image.php",
        json={
            "prompt": prompt,
            "size": size,
            "style": "vivid"
        }
    )
    return response.json()


def get_config():
    """Obtener configuración del asistente"""
    response = requests.get(f"{API_URL}/config-endpoint.php")
    return response.json()


# Ejemplo de uso
if __name__ == "__main__":
    print("🤖 GPT Chat API - Ejemplo Python\n")
    
    # 1. Login
    print("1. Iniciando sesión...")
    login_result = login()
    print(f"   Resultado: {login_result}\n")
    
    # 2. Obtener configuración
    print("2. Obteniendo configuración...")
    config = get_config()
    print(f"   Asistente: {config['assistant']['name']}\n")
    
    # 3. Enviar mensaje
    print("3. Enviando mensaje...")
    message = "Hola, ¿cómo estás?"
    chat_response = send_message(message)
    print(f"   Pregunta: {message}")
    print(f"   Respuesta: {chat_response.get('response', 'Error')[:100]}...\n")
    
    # 4. Generar imagen
    print("4. Generando imagen...")
    image_result = generate_image("Un paisaje hermoso al atardecer")
    if image_result.get('success'):
        print(f"   Imagen generada: {image_result['image_url']}")
    else:
        print(f"   Error: {image_result.get('error')}")
