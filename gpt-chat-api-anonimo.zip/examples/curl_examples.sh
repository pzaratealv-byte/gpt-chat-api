#!/bin/bash
# Ejemplos de uso de GPT Chat API con cURL

# Configuración
API_URL="https://tudominio.com/api"
PASSWORD="tu-contraseña"
SESSION_ID="session_curl_$(date +%s)"

echo "🤖 GPT Chat API - Ejemplos cURL"
echo "================================"
echo ""

# 1. Login
echo "1. Login:"
curl -X POST "${API_URL}/auth.php?action=login" \
  -H "Content-Type: application/json" \
  -d "{\"password\": \"${PASSWORD}\"}" \
  -c cookies.txt
echo ""
echo ""

# 2. Verificar sesión
echo "2. Verificar sesión:"
curl -X GET "${API_URL}/auth.php?action=check" \
  -b cookies.txt
echo ""
echo ""

# 3. Obtener configuración
echo "3. Configuración del asistente:"
curl -X GET "${API_URL}/config-endpoint.php" \
  -b cookies.txt
echo ""
echo ""

# 4. Enviar mensaje
echo "4. Enviar mensaje:"
curl -X POST "${API_URL}/chat.php" \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d "{
    \"message\": \"Hola, ¿cómo estás?\",
    \"sessionId\": \"${SESSION_ID}\"
  }"
echo ""
echo ""

# 5. Generar imagen
echo "5. Generar imagen:"
curl -X POST "${API_URL}/generate-image.php" \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d "{
    \"prompt\": \"Un paisaje hermoso al atardecer\",
    \"size\": \"1024x1024\",
    \"style\": \"vivid\"
  }"
echo ""
echo ""

# 6. Logout
echo "6. Logout:"
curl -X GET "${API_URL}/auth.php?action=logout" \
  -b cookies.txt
echo ""

echo ""
echo "✅ Ejemplos completados"
