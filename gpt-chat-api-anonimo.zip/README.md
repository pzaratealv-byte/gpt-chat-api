# 🤖 GPT Chat API

API REST en PHP para integrar chat con inteligencia artificial (OpenAI GPT-4) y generación de imágenes (DALL-E 3) en cualquier proyecto.

## ✨ Características

- 💬 **Chat con GPT-4** - Conversaciones con contexto y memoria
- 🎨 **Generación de imágenes** - Integración con DALL-E 3
- 🔐 **Autenticación por contraseña** - Protege el acceso
- 📧 **Envío de conversaciones por email** - Comparte chats
- 🎯 **Personalizable** - Configura la temática del asistente
- 📱 **API REST** - Fácil integración con cualquier frontend

## 🚀 Instalación Rápida

### Requisitos
- PHP 7.4+
- Extensión cURL habilitada
- API Key de OpenAI

### Pasos

1. **Descargar y subir**
   ```
   Sube la carpeta api/ a tu servidor PHP
   ```

2. **Configurar**
   ```
   Renombra api/config.example.php a api/config.php
   Edita api/config.php con tu API Key de OpenAI
   ```

3. **Probar**
   ```
   Accede a https://tudominio.com/api/health.php
   ```

## 📡 Endpoints

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/auth.php?action=login` | Iniciar sesión |
| POST | `/api/chat.php` | Enviar mensaje al chatbot |
| POST | `/api/generate-image.php` | Generar imagen con DALL-E |
| GET | `/api/config-endpoint.php` | Obtener configuración |
| GET | `/api/health.php` | Verificar estado |

## 💡 Ejemplo de uso (JavaScript)

```javascript
// Login
await fetch('/api/auth.php?action=login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ password: 'tu-contraseña' })
});

// Chat
const response = await fetch('/api/chat.php', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    message: 'Hola, ¿cómo estás?',
    sessionId: 'session_123'
  })
});

const data = await response.json();
console.log(data.response);
```

## ⚙️ Personalización

Edita `api/config.php` para cambiar:

- **Temática del asistente** - Modifica el `system_prompt`
- **Modelo de OpenAI** - gpt-4, gpt-3.5-turbo
- **Contraseña de acceso** - Genera un nuevo hash
- **Configuración de email** - Opcional

### Generar hash de contraseña

```php
<?php
echo password_hash('tu_contraseña', PASSWORD_DEFAULT);
?>
```

## 🔒 Seguridad

- Contraseñas hasheadas con bcrypt
- Sesiones con tiempo de expiración
- Validación de autenticación en todos los endpoints

## 📝 Licencia

MIT License
