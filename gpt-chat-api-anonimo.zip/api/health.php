<?php
// Health check
// TFM - Noelia Medrano

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$config = require __DIR__ . '/config.php';

echo json_encode([
    'status' => 'OK',
    'timestamp' => date('c'),
    'assistant' => $config['assistant']['name'],
    'php_version' => phpversion()
]);
