<?php
// Autenticacion - Asistente IA
// TFM - Noelia Medrano

session_start();

// Cargar configuracion
$config = require __DIR__ . '/config.php';

// Funcion para verificar si el usuario esta autenticado
function isAuthenticated() {
    global $config;
    
    // Si la autenticacion esta deshabilitada, permitir acceso
    if (!$config['auth']['enabled']) {
        return true;
    }
    
    // Verificar sesion
    if (!isset($_SESSION[$config['auth']['session_name']])) {
        return false;
    }
    
    // Verificar tiempo de expiracion
    $authData = $_SESSION[$config['auth']['session_name']];
    if (time() - $authData['time'] > $config['auth']['session_timeout']) {
        // Sesion expirada
        unset($_SESSION[$config['auth']['session_name']]);
        return false;
    }
    
    // Actualizar tiempo de ultima actividad
    $_SESSION[$config['auth']['session_name']]['time'] = time();
    
    return true;
}

// Funcion para requerir autenticacion (para APIs)
function requireAuth() {
    if (!isAuthenticated()) {
        http_response_code(401);
        echo json_encode(['error' => 'No autorizado', 'redirect' => 'login.html']);
        exit;
    }
}

// Funcion para hacer login
function login($password) {
    global $config;
    
    if (!$config['auth']['enabled']) {
        return ['success' => true];
    }
    
    // Verificar contraseña
    if (password_verify($password, $config['auth']['password_hash'])) {
        $_SESSION[$config['auth']['session_name']] = [
            'authenticated' => true,
            'time' => time()
        ];
        return ['success' => true];
    }
    
    return ['success' => false, 'error' => 'Contraseña incorrecta'];
}

// Funcion para logout
function logout() {
    global $config;
    unset($_SESSION[$config['auth']['session_name']]);
    session_destroy();
}

// Manejar peticiones
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Metodo no permitido']);
            exit;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $password = $input['password'] ?? '';
        
        if (empty($password)) {
            echo json_encode(['success' => false, 'error' => 'Contraseña requerida']);
            exit;
        }
        
        $result = login($password);
        echo json_encode($result);
        break;
        
    case 'logout':
        logout();
        echo json_encode(['success' => true]);
        break;
        
    case 'check':
        echo json_encode(['authenticated' => isAuthenticated()]);
        break;
        
    default:
        echo json_encode(['authenticated' => isAuthenticated()]);
}
