<?php
// API Send Email - Asistente IA
// TFM - Noelia Medrano

session_start();

// Verificar autenticacion
require_once __DIR__ . '/auth.php';
requireAuth();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Cargar configuracion
$config = require __DIR__ . '/config.php';

// Obtener datos
$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
$subject = $input['subject'] ?? 'Conversacion con Asistente IA';
$sessionId = $input['sessionId'] ?? 'default';

// Validar email
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['error' => 'Email invalido']);
    exit;
}

// Obtener conversacion
session_start();
$conversation = $_SESSION['conversations'][$sessionId] ?? [];

if (empty($conversation) || count($conversation) <= 1) {
    echo json_encode(['error' => 'No hay conversacion para enviar']);
    exit;
}

// Formatear conversacion
$html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }
        h2 { color: #a855f7; border-bottom: 2px solid #a855f7; padding-bottom: 10px; }
        .header { background: linear-gradient(135deg, #a855f7, #ec4899); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 24px; }
        .header p { margin: 5px 0 0 0; opacity: 0.9; }
        .message { margin-bottom: 20px; padding: 15px; border-radius: 8px; }
        .message.user { background: #e0f2fe; border-left: 4px solid #3b82f6; }
        .message.assistant { background: #f3e8ff; border-left: 4px solid #a855f7; }
        .message strong { display: block; margin-bottom: 8px; color: #555; }
        .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #888; font-size: 12px; text-align: center; }
        hr { border: none; border-top: 1px solid #eee; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Conversacion con ' . htmlspecialchars($config['assistant']['name']) . '</h1>
        <p>Enviado el ' . date('d/m/Y H:i:s') . '</p>
    </div>';

foreach ($conversation as $msg) {
    if ($msg['role'] === 'system') continue;
    $role = $msg['role'] === 'user' ? 'Tu' : $config['assistant']['name'];
    $class = $msg['role'] === 'user' ? 'user' : 'assistant';
    $html .= '<div class="message ' . $class . '">';
    $html .= '<strong>' . htmlspecialchars($role) . ':</strong>';
    $html .= '<p>' . nl2br(htmlspecialchars($msg['content'])) . '</p>';
    $html .= '</div>';
}

$html .= '<div class="footer">
        <p>Este email fue enviado desde el Asistente IA - TFM Noelia Medrano</p>
    </div>
</body>
</html>';

// Intentar enviar con diferentes metodos
$success = false;
$errorMsg = '';

// Metodo 1: Usar PHPMailer si esta instalado
if (file_exists(__DIR__ . '/PHPMailer/PHPMailer.php')) {
    require_once __DIR__ . '/PHPMailer/PHPMailer.php';
    require_once __DIR__ . '/PHPMailer/SMTP.php';
    require_once __DIR__ . '/PHPMailer/Exception.php';
    
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $config['email']['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $config['email']['username'];
        $mail->Password = $config['email']['password'];
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = $config['email']['port'];
        
        $mail->setFrom($config['email']['username'], $config['assistant']['name']);
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $html;
        
        $success = $mail->send();
    } catch (Exception $e) {
        $errorMsg = $e->getMessage();
    }
}

// Metodo 2: Usar mail() de PHP
if (!$success) {
    $boundary = md5(time());
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-Type: text/html; charset=UTF-8' . "\r\n";
    $headers .= 'From: ' . $config['email']['from'] . "\r\n";
    $headers .= 'Reply-To: ' . $config['email']['username'] . "\r\n";
    $headers .= 'X-Mailer: PHP/' . phpversion() . "\r\n";
    
    $success = mail($email, $subject, $html, $headers);
}

if ($success) {
    echo json_encode([
        'message' => 'Email enviado correctamente',
        'to' => $email,
        'timestamp' => date('c')
    ]);
} else {
    echo json_encode([
        'error' => 'Error al enviar el email',
        'details' => $errorMsg ?: 'Verifica la configuracion de email en el servidor'
    ]);
}
