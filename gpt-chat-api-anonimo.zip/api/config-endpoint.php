<?php
// Configuracion para el frontend
// TFM - Noelia Medrano

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$config = require __DIR__ . '/config.php';

echo json_encode([
    'assistant' => [
        'name' => $config['assistant']['name'],
        'welcomeMessage' => $config['assistant']['welcome_message'],
        'inputPlaceholder' => $config['assistant']['input_placeholder'],
    ]
]);
