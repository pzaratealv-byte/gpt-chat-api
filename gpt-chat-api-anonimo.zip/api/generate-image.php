<?php
// API Generar Imagen - DALL-E
// TFM - Noelia Medrano

session_start();

// Verificar autenticacion
require_once __DIR__ . '/auth.php';
requireAuth();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Cargar configuracion
$config = require __DIR__ . '/config.php';

// Obtener datos
$input = json_decode(file_get_contents('php://input'), true);
$prompt = $input['prompt'] ?? '';
$size = $input['size'] ?? '1024x1024';
$style = $input['style'] ?? 'vivid';

if (empty($prompt)) {
    echo json_encode(['error' => 'El prompt no puede estar vacio']);
    exit;
}

// Limitar longitud del prompt
if (strlen($prompt) > 1000) {
    $prompt = substr($prompt, 0, 1000);
}

// Mejorar el prompt para marketing
$enhancedPrompt = "Imagen profesional para marketing digital: " . $prompt;

// Llamar a OpenAI DALL-E
$ch = curl_init('https://api.openai.com/v1/images/generations');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $config['openai']['api_key']
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'model' => 'dall-e-3',
    'prompt' => $enhancedPrompt,
    'n' => 1,
    'size' => $size,
    'style' => $style,
    'quality' => 'standard'
]));

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    $error = json_decode($response, true);
    echo json_encode([
        'error' => 'Error al generar la imagen',
        'details' => $error['error']['message'] ?? 'Error desconocido'
    ]);
    exit;
}

$data = json_decode($response, true);

if (empty($data['data'][0]['url'])) {
    echo json_encode(['error' => 'No se pudo obtener la URL de la imagen']);
    exit;
}

// Descargar la imagen y guardarla localmente
$imageUrl = $data['data'][0]['url'];
$revisedPrompt = $data['data'][0]['revised_prompt'] ?? $prompt;

// Generar nombre unico
$filename = 'img_' . time() . '_' . uniqid() . '.png';
$uploadDir = __DIR__ . '/../uploads/';

// Crear directorio si no existe
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$localPath = $uploadDir . $filename;

// Descargar imagen
$imageData = file_get_contents($imageUrl);
if ($imageData === false) {
    echo json_encode(['error' => 'Error al descargar la imagen']);
    exit;
}

file_put_contents($localPath, $imageData);

// URL publica
$publicUrl = 'uploads/' . $filename;

echo json_encode([
    'success' => true,
    'image_url' => $publicUrl,
    'original_url' => $imageUrl,
    'prompt' => $prompt,
    'revised_prompt' => $revisedPrompt,
    'size' => $size,
    'timestamp' => date('c')
]);
