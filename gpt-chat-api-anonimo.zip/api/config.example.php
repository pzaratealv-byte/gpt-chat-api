<?php
/**
 * Configuración de ejemplo
 * Copia este archivo a config.php y completa tus datos
 */

return [
    // ============================================
    // AUTENTICACIÓN
    // ============================================
    'auth' => [
        // Habilitar/deshabilitar protección por contraseña
        'enabled' => true,
        
        // Hash de la contraseña
        // Generar con: password_hash('tu_contraseña', PASSWORD_DEFAULT)
        'password_hash' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
        
        // Nombre de la sesión
        'session_name' => 'chatbot_auth',
        
        // Tiempo de expiración de sesión (en segundos)
        'session_timeout' => 3600, // 1 hora
    ],
    
    // ============================================
    // OPENAI
    // ============================================
    'openai' => [
        // Tu API Key de OpenAI (obligatorio)
        // Obtener en: https://platform.openai.com/api-keys
        'api_key' => 'sk-tu-api-key-aqui',
        
        // Modelo a usar
        'model' => 'gpt-4', // o 'gpt-3.5-turbo'
        
        // Temperatura: 0 = conservador, 1 = creativo
        'temperature' => 0.7,
        
        // Máximo de tokens en la respuesta
        'max_tokens' => 1000,
    ],
    
    // ============================================
    // ASISTENTE
    // ============================================
    'assistant' => [
        // Nombre del asistente
        'name' => 'Asistente IA',
        
        // Mensaje de bienvenida
        'welcome_message' => 'Hola, soy tu asistente virtual. ¿En qué puedo ayudarte hoy?',
        
        // Placeholder del input
        'input_placeholder' => 'Escribe tu pregunta...',
        
        // Prompt del sistema (define el comportamiento de la IA)
        // Personaliza esto según tu necesidad
        'system_prompt' => 'Eres un asistente virtual inteligente y servicial.

Tu objetivo es ayudar a los usuarios con sus consultas de manera clara, profesional y concisa.

Responde de manera amable y profesional.
Si no sabes algo, admítelo honestamente.
Mantén un tono conversacional y cercano.'
    ],
    
    // ============================================
    // EMAIL (Opcional)
    // ============================================
    'email' => [
        // Habilitar envío de emails
        'enabled' => false,
        
        // Servidor SMTP
        'host' => 'smtp.gmail.com',
        'port' => 587,
        
        // Credenciales
        'username' => 'tu-email@gmail.com',
        'password' => 'tu-app-password',
        
        // Remitente
        'from' => 'Asistente IA <tu-email@gmail.com>',
    ]
];
