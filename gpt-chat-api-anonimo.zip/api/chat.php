<?php
// API Chat - Asistente IA
// TFM - Noelia Medrano

session_start();

// Verificar autenticacion
require_once __DIR__ . '/auth.php';
requireAuth();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Cargar configuracion
$config = require __DIR__ . '/config.php';

// Obtener datos de la peticion
$input = json_decode(file_get_contents('php://input'), true);
$message = $input['message'] ?? '';
$sessionId = $input['sessionId'] ?? 'default';

if (empty($message)) {
    echo json_encode(['error' => 'El mensaje no puede estar vacio']);
    exit;
}

// Iniciar sesion para guardar conversacion
if (!isset($_SESSION['conversations'])) {
    $_SESSION['conversations'] = [];
}
if (!isset($_SESSION['conversations'][$sessionId])) {
    $_SESSION['conversations'][$sessionId] = [
        ['role' => 'system', 'content' => $config['assistant']['system_prompt']]
    ];
}

// Agregar mensaje del usuario
$_SESSION['conversations'][$sessionId][] = [
    'role' => 'user',
    'content' => $message
];

// Preparar mensajes para OpenAI (ultimos 20)
$messages = $_SESSION['conversations'][$sessionId];
if (count($messages) > 21) {
    $systemMsg = $messages[0];
    $recent = array_slice($messages, -20);
    $messages = array_merge([$systemMsg], $recent);
}

// Llamar a OpenAI
$ch = curl_init('https://api.openai.com/v1/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $config['openai']['api_key']
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'model' => $config['openai']['model'],
    'messages' => $messages,
    'temperature' => $config['openai']['temperature'],
    'max_tokens' => $config['openai']['max_tokens']
]));

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    $error = json_decode($response, true);
    echo json_encode([
        'error' => 'Error al comunicarse con OpenAI',
        'details' => $error['error']['message'] ?? 'Error desconocido'
    ]);
    exit;
}

$data = json_decode($response, true);
$assistantResponse = $data['choices'][0]['message']['content'];

// Guardar respuesta en sesion
$_SESSION['conversations'][$sessionId][] = [
    'role' => 'assistant',
    'content' => $assistantResponse
];

// Responder
echo json_encode([
    'response' => $assistantResponse,
    'sessionId' => $sessionId,
    'timestamp' => date('c')
]);
